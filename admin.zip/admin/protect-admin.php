<?php
if(!isset($_SESSION)){
    session_start();
}

if(!isset($_SESSION['id'])){
    die("Você não pode acessar esta página pq não está logado!<p><a href=\"login.php\">Faça Login</a></p>");
}else{
    echo "Vc está logado!";
require_once("./_conexao/conexao.php");
try{
    $sql = $conexao->prepare("SELECT * FROM admin WHERE id_user_FK = :idUser ");
    $sql-> bindValue("idUser", $_SESSION['id'], PDO::PARAM_INT);
    $sql->execute();
    // $select = $conexao->query($sql);
    $result = $sql->fetchAll();
    $total = $sql->rowCount();

    if($total > 0){
        echo $_SESSION['nome'];
        echo "<p>total maior que zero</p>";
        header("Location:./ani-view.php");
    }else{
        echo "<p>total menor que zero</p>";
        // die("Você não tem permissão para acessar esta página!!! <a href=\"../index.php\">Sair</a>");
        header("Location:../index.php");
    }
}
catch(PDOException $e) {
    echo "Erro: ".$e->getMessage();
}
}
?>